def world():
	print('Hello')
	return